package com.capg.bank.ui;

import java.util.Scanner;

import com.capg.bank.bean.Customer;
import com.capg.bank.exception.MyException;
import com.capg.bank.service.ServiceImp;



public class Client {

	public static void main(String[] args)
	{
		
		ServiceImp serv=new ServiceImp();
		
while(true)
{		System.out.println("\nWelcome to banking system");
				System.out.println("1.Create an account");
				System.out.println("2.Show balance");
				System.out.println("3.Withdraw amount");
				System.out.println("4.Deposit amount");
				System.out.println("5.Fund transfer");
				System.out.println("6.Print transactions");
				System.out.println("7.Exit");
		

				Scanner sc = new Scanner(System.in);
				Scanner sc1 = new Scanner(System.in);
				int option = sc.nextInt();
				String cname,caddress,cphnno,caadharno;
				int cage;
				double bal,balance;
				int id,funacc	;
				double amt;
				switch (option) 
	{
				case 1:
					
					try
					{
						Customer bean = new Customer();
						boolean flag;
					do {
					System.out.println("\nEnter your name");
					cname = sc1.nextLine();
					flag=serv.validatename(cname);
					}while(flag==false);
					do {
						System.out.println("\nEnter your age");
						cage = sc.nextInt();
						flag=serv.validateage(cage);
						}while(flag==false);
					do {
					System.out.println("\nEnter your address");
					caddress= sc1.nextLine();
					flag=serv.validateaddress(caddress);
					}while(flag==false);
					do
					{
						System.out.println("\nEnter your mobile number");
						cphnno=sc.next();
						flag=serv.validatephnno(cphnno);
					}while(flag==false);
					do
					{
					System.out.println("\nEnter your Aadharno");
					caadharno=sc.next();
				    flag=serv.validatepanno(caadharno);
					}while(flag==false);
					do
					{
						System.out.println("\nEnter the opening balance");
						balance=sc.nextDouble();
						flag=serv.validatebal(balance);
					}while(flag==false);
					
					bean.setCname(cname);
					bean.setCaddress(caddress);
					bean.setCphnno(cphnno);
					bean.setCaadharno(caadharno);
					bean.setBalance(balance);
					bean.setCage(cage);
					serv.createaccount(bean);
					
					System.out.println("\n Your account number is \t"+bean.getAccnum());
					break;
					}catch(MyException me)
					{
						System.out.println("\n The exception is"+ me.getMessage());
					}
					
				
				
				
				case 2:
					System.out.println("Enter the account number");
				try {
					do
					{
						id=sc.nextInt();
					}while(serv.validateaccno(id)==false);
					bal=serv.showbalance(id);
					System.out.println("\n The balance in the account\t"+id+"is\t"+bal);
					break;
				}catch(MyException me)
				{
					System.out.println("\n The exception is"+ me.getMessage());
				}
				
					
				case 3:
					System.out.println("Enter the account number:");
				try {
					do
						{
						id=sc.nextInt();
						}while(serv.validateaccno(id)==false);
					System.out.println(" Enter the amount to be withdrawn:");
					amt=sc.nextDouble();
					bal=serv.withdraw(id,amt);
					System.out.println("\n Amount has been withdrawn and the balance is\t"+bal);
					break;
					}catch(MyException me)
					{
						System.out.println("\n The exception is"+ me.getMessage());
					}
					
					
				case 4:
					System.out.println("Enter the account number:");
					try{
						do
						{
						id=sc.nextInt();
						}while(serv.validateaccno(id)==false);
					System.out.println(" Enter the amount to be deposited:");
					amt=sc.nextDouble();
					bal=serv.deposit(id,amt);
					System.out.println("\n amount has been deposited and the balance is\t"+bal);
					break;
					}catch(MyException me)
					{
						System.out.println("\n The exception is"+ me.getMessage());
					}
					
				
				case 5:
					
					System.out.println("Enter the account number:");
					id=sc.nextInt();
					System.out.println("Enter the account number to be transferred");
					funacc=sc.nextInt();
					System.out.println("\n Enter the amount to be transferred");
					amt=sc.nextDouble();
					break;
				case 6:
					try
					{
					System.out.println("Enter the account number");
					id=sc.nextInt();
					serv.printtrans(id);
					break;
					}catch(MyException me)
					{
						System.out.println("\n The exception is"+ me.getMessage());
					}
					
				case 7:
					System.exit(0);
					break;

				default:
					System.out.println("Wrong choice");
					break;
	}

}
	}
	

}
