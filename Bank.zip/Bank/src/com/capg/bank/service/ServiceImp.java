package com.capg.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capg.bank.bean.Customer;
import com.capg.bank.dao.DaoImp;
import com.capg.bank.exception.MyException;


public class ServiceImp implements IService{
	DaoImp dao=new DaoImp();
	
	public int createaccount(Customer c)throws MyException
	{
		return dao.createaccount(c);
	}
	
	public double showbalance(int id)throws MyException
	{
		return dao.showbalance(id);
	}
	public void fundtrans(int id,int funacc,double amt)throws MyException
	{
		 dao.fundtrans(id,funacc,amt);
	}
	public void printtrans(int id)throws MyException
	{
		 dao.printtrans(id);
	}
	public double withdraw(int id,double amt)throws MyException 
	{
		return dao.withdraw(id,amt);
	}
	
	public double deposit(int id,double amt)throws MyException 
	{
		return dao.deposit(id,amt);
	}
	public boolean validatename(String cname)throws MyException
	{
		boolean flag=false;
		Pattern Name=Pattern.compile("^[A-Z][a-z\\s]+$");
		Matcher Namematch=Name.matcher(cname);
		if(Namematch.matches()&&cname.length()>2) 
		{
			flag=true;
		}
		else
		{
			System.err.println("\n Enter the NAME correctly");
		}
			return flag;
	}
	public boolean validateage(int age)throws MyException
	{
		boolean flag=false;
		if(age>10&&age<80)
		{
			return true;
		}
		else
		{
			System.err.println("\n Invalid age");
		}
		return flag;
	}
	
	public boolean validatephnno(String cphnno)throws MyException
	{
		boolean flag=false;
		Pattern Mob=Pattern.compile("[6-9][0-9]{9}");
		Matcher Mobmatch=Mob.matcher(cphnno);
		if(Mobmatch.matches()) 
		{
			flag=true;
			}
		else
		{
			System.err.println("\n Enter the MOBILE NUMBER correctly");
		}
			return flag;
		}
	public boolean validateaddress(String caddress)throws MyException
	{
		boolean flag=false;
		Pattern Addr=Pattern.compile("^[0-9][A-Za-z0-9\\s,]*");
		Matcher Addrmatch=Addr.matcher(caddress);
		if(Addrmatch.matches()&&caddress.length()>3) 
		{
			flag=true;
			}
		else
		{
			System.err.println("\n Enter the ADDRESS correctly");
		}
			return flag;
		}
	public boolean validatepanno(String caadharno)throws MyException
	{
		boolean flag=false;
		Pattern Pan=Pattern.compile("[0-9]{12}");
		Matcher Panmatch=Pan.matcher(caadharno);
		if(Panmatch.matches())
		{
			flag=true;
		}
		else
		{
			System.err.println("\n Enter the AADHAR NUMBER correctly");
		}
			return flag;
	}
	public boolean validateaccno(int id)throws MyException
	{
		boolean flag=false;
		{
			if(id>=1000)
			{
				return dao.accvalid(id);
				
						}
			else
				{
				System.err.println("\n Invalid account number");
				return false;
				}
		}
	}

	public boolean validatebal(double balance)throws MyException {
		{
			boolean flag=false;
			if(balance>100)
			{
				flag=true;
			}
			else
			{
				System.err.println("\n Enter a amount greater than 100");
			}
		
		return flag;
	}}}


	
	
	
	


