package com.capg.bank.service;

import com.capg.bank.bean.Customer;
import com.capg.bank.exception.MyException;

public interface IService {
	public int createaccount(Customer c)throws MyException;
	public boolean validatename(String cname)throws MyException;
	public boolean validateaddress(String caddress)throws MyException;
	public boolean validatephnno(String cphnno)throws MyException;
	public boolean validatepanno(String caadharno)throws MyException;
	public boolean validateaccno(int id)throws MyException;
	public boolean validateage(int age)throws MyException;
	public boolean validatebal(double balance)throws MyException;
	public double withdraw(int id,double amt)throws MyException;
	public double deposit(int id,double amt)throws MyException;
	public double showbalance(int id)throws MyException;
	public void fundtrans(int id,int funacc,double amt)throws MyException;
	public void printtrans(int id)throws MyException;
	
}
