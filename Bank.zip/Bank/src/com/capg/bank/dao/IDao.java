
package com.capg.bank.dao;

import com.capg.bank.bean.Customer;
import com.capg.bank.exception.MyException;

public interface IDao 
{
	public int createaccount(Customer c)throws MyException;
	public double withdraw(int id,double amt)throws MyException;
	public double deposit(int id,double amt)throws MyException;
	public double showbalance(int id)throws MyException;
	public void fundtrans(int id,int funacc,double amt)throws MyException;
	public void printtrans(int id)throws MyException;
	public boolean accvalid(int id)throws MyException;

}
