package com.capg.bank.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capg.bank.bean.Customer;
import com.capg.bank.exception.MyException;

public class DaoImp implements IDao {
	double balance;
	public static Map<Integer,Customer>m=new HashMap<Integer,Customer>();
	int accnum=1000;
	public int createaccount(Customer bean)throws MyException
	{
		
		System.out.println("\n Hi\t"+bean.getCname());
		bean.setAccnum(accnum);
		m.put(bean.getAccnum(),bean);
		//System.out.println(m.keySet());
		accnum++;
		return bean.getAccnum();
		
	}
	public double showbalance(int id)throws MyException
	{
		double d=0;
		for(Integer k:m.keySet())
		{
		if(k==id)
		{
			Customer c=new Customer();
			
			c=m.get(id);
			d= c.balance;
		}
		}
		return d;
		}
	public double withdraw(int id,double amt)throws MyException
	{	
		double d=0;
		for(Integer k:m.keySet())
		{
		if(k==id)
		{
			Customer c=new Customer();
			c=m.get(id);
			if(c.balance>=amt)
			{
				c.balance-=amt;
			}
			m.put(accnum,c);
			d=c.balance;
		}
	}
		return d;
		}
	public double deposit(int id,double amt) throws MyException
	{
		double d=0;
		for(Integer k:m.keySet())
		{
		if(k==id)
		{
			
			Customer c=new Customer();
			c=m.get(id);
			c.balance+=amt;
			m.put(accnum,c);
			d=c.balance;
}
		}
		return d;
	}
	public void fundtrans(int id,int funacc,double amt) throws MyException
	{
		double bal1=0.0;
		double bal2=0.0;
		boolean valid1=false;
		boolean valid2=false;
		valid1=accvalid(id);
		valid2=accvalid(funacc);
		if(valid1&&valid2==true)
		{
			bal1=withdraw(id,amt);
			bal2=deposit(funacc,amt);
			System.out.println("\n The updated balance in acc"+id+"is"+bal1+"and in"+funacc+"is"+bal2);
		}
	}
		{
		
		}
	public void printtrans(int id1) throws MyException
	{
		
	}
	public boolean accvalid(int id)throws MyException
	{
		Set<Integer>k=m.keySet();
		Iterator<Integer>it=k.iterator();
		while(it.hasNext())
		{
			int accnum=it.next();
			if(accnum==id)
			{
				return true;
				}
		}
		System.err.println("\n Invalid account number");
		return false;
	}
}



