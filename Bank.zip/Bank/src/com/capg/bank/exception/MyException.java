package com.capg.bank.exception;

public class MyException extends Exception
{
MyException(){
	super();
}
MyException(String message)
{
	super(message);
	}
}
