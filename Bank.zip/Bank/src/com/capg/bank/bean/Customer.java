package com.capg.bank.bean;

public class Customer {
	
	private String cname;
	private String caddress;
	private String cphnno;
	private String caadharno;
	private int accnum;
	private int cage;
	public double balance;

	public Customer(String cname,int cage,String caddress,String cphnno,String caadharno, double balance)
	{
		super();
		this.cname=cname;
		this.caddress=caddress;
		this.cphnno=cphnno;
		this.caadharno=caadharno;
		this.balance=balance;
		this.cage=cage;
	}
	
	public int getCage() {
		return cage;
	}

	public void setCage(int cage) {
		this.cage = cage;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer() {
		// TODO Auto-generated constructor stub
	}


	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCaddress() 
	{
		return caddress;
	}

	public int getAccnum() {
		return accnum;
	}

	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}
	public String getCphnno()	
	{
	return cphnno;
	}
	public void setCphnno(String cphnno){
	this.cphnno=cphnno;
	}
	public String getcaadharno()	
	{
	return caadharno;
	}
	public void setCaadharno(String caadharno){
	this.caadharno=caadharno;
	}

	@Override
	public String toString() {
		return "Bank Customer:"+  "[cname=" + cname + ",age="+cage+", address="+ caddress +"\n"+", phnno=" + cphnno + ", aadharno=" +caadharno+",balance="+balance+"]";
				
}
	
}

